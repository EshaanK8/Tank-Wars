/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game;

import java.awt.Graphics;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferStrategy;
import java.util.logging.Level;
import java.util.logging.Logger;
import main.display.Display;
import main.game.gfx.Assets;
import main.game.input.KeyManager;
import main.game.input.MouseManager;
//import main.game.input.KeyManager2;
import main.game.states.GameState;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;
import static main.game.states.StateManager.getState;

/**
 *
 * @author Eshaan
 */

public class Game implements Runnable { //Allow game to be run on a thread
    private Display display;
    public int width, height; //dimension attributes
    public String title; //attribute
    private boolean running = false; //Used for while loop to allow game to run
    private Thread thread;
    private BufferStrategy bs;
    private Graphics graphics; //Allows for drawing to the canvas
    private MouseManager mouseManager;
    public int hPositionx;
    public int hPositiony;
    public int hHeight;
    public int vPositionx;
    public int vPositiony;
    public int vWidth;
    public int xPos;
    public int yPos;
    public int rwidth;
    public int rheight;
    
    
    //States
    public State gameState;
    public State menuState;
    
    //Input
    private KeyManager keyManager;
    
    //Handler
    private Handler handler;
    
    
    //Constructor
    public Game(String title, int width, int height){
        this.width = width; 
        this.height = height;
        keyManager = new KeyManager();
        mouseManager = new MouseManager();
        //keyManager2 = new KeyManager2();
    }
    
    
    //Initialization method
    private void init(){
        //Call Display class
        display = new Display(title, width, height);
        display.getFrame().addKeyListener(keyManager);//Add a key listener to the JFrame
        display.getFrame().addMouseListener((MouseListener) mouseManager);//Add a key listener to the JFrame
        display.getFrame().addMouseMotionListener((MouseMotionListener) mouseManager);
        display.getCanvas().addMouseListener((MouseListener) mouseManager);//Add a key listener to the JFrame
        display.getCanvas().addMouseMotionListener((MouseMotionListener) mouseManager);
        Assets.init();
        
        
        handler = new Handler(this);
        
        gameState = new GameState(handler); //Initialize game state
        menuState = new MenuState(handler); //Initialize menu state
        StateManager.setState(menuState);
     
        
       
        //StateManager.setState(menuState); //Set the current state to GameState object
        
    }
    
    //Tick method
    private void tick(){
        keyManager.tick();
        
        
        
        //If the current state exists, then tick
        if (StateManager.getState() != null)
            StateManager.getState().tick();
    }
    
    //Render method
    private void render(){
        
        bs = display.getCanvas().getBufferStrategy();
        
        if (bs == null){ //If the canvas does not have a buffer strategy
            display.getCanvas().createBufferStrategy(3); //Use three buffers
            return;
        }
        
        graphics = bs.getDrawGraphics();
        
        
        graphics.clearRect(0, 0, width, height);//Clear screen
        
        //If the current state exists, then render
        if (StateManager.getState() != null)
            StateManager.getState().render(graphics);
        
        bs.show(); //Show the buffer
        graphics.dispose(); //Dispose of the graphics object
    }
    
    //Run method
    public void run(){
        init();
        
        //Variables
        int fps = 60; //Sets frames per second to 60 (ticks and renders per second)
        double timePerTick = 1000000000/fps;//Max time that tick and render methods can run for them to run 60 times/second 
        double delta = 0; //Amount of time needed to call tick and render methods again
        long now; //Current time in nanoseconds
        long lastTime = System.nanoTime();//Nanoseconds the computer runs at as the while loop is started
        long timer = 0; //Times until 1 second to determine tick and render methods were called
        long ticks = 0; //Counts times tick and render have run during a second
        
        
        //Loop for the game to continue
        while(running){
            now = System.nanoTime(); //Determine current time
            
            //Determine when tick and render methods must be called again 
            delta += (now-lastTime)/timePerTick; // (Current time - time since code was run)/ max time for tick and render methods
            timer += now-lastTime;//Time since code was run
            lastTime = now; //Update lastTime to current time
            
            //If time>= 1 then the tick and render methods must start
            if (delta >=1){
                tick();
                render();
                ticks++;
                delta--; //The methods have been run, so subtract by 1
            }
            
            //Displays frames per second for debugging purposes
            if (timer >= 1000000000){
                ticks = 0;
                timer = 0;
            }
        }
        
        stop(); //Call stop method in case code has not yet stopped
        
    }
    
    //Method returns key manager1 object so other classes can access it
    public KeyManager getKeyManager(){
        return keyManager;
    }
    
    public MouseManager getMouseManager(){
        return mouseManager;
    }
   
    
    /*
    //Method to store rectangles
    public void paint (Graphics g) {    
        Rectangle r = new Rectangle( xPos, yPos, rwidth, rheight);
        g.fillRect(
           (int)r.getX(),
           (int)r.getY(),
           (int)r.getWidth(),
           (int)r.getHeight()
        );  
       
    }*/
    
  
    
    //Threads
    //Start thread method
    public synchronized void start(){
        if (running == true)
            return; //Do not execute if run is already = true
        running = true; //Run the game
        thread = new Thread(this); //Initialize thread to this game class 
        thread.start(); //Start the thread
    }
    
    //Stop thread method
    public synchronized void stop(){
        if (running == false)
            return;
        running = false;
        try {
            thread.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    

}

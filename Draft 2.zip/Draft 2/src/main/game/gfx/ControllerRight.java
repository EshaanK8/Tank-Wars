package main.game.gfx;

import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import Bullets.BulletR;

/**
 *
 * @author Eshaan
 */
public class ControllerRight {
    private LinkedList<BulletR> b = new LinkedList<BulletR>();
    BulletR TempBulletR;

    Handler handler;
    
    public ControllerRight(Handler handler){
       this.handler = handler;
       addBullet(new BulletR(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletR = b.get(i);
            TempBulletR.tick();
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletR = b.get(i);
            TempBulletR.render(graphics);
        }
    }
    
    
    public void addBullet(BulletR block){
        b.add(block);
    } 
    
     public void removeBullet(BulletR block){
        b.remove(block);
    } 
}

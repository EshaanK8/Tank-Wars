/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.gfx;

import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import Bullets.BulletUp;

/**
 *
 * @author Eshaan
 */
public class ControllerUp {
    private LinkedList<BulletUp> b = new LinkedList<BulletUp>();
    BulletUp TempBulletUp;

    Handler handler;
    
    public ControllerUp(Handler handler){
       this.handler = handler;
       addBullet(new BulletUp(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp = b.get(i);
            TempBulletUp.tick();
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp = b.get(i);
            TempBulletUp.render(graphics);
        }
    }
    
    
    public void addBullet(BulletUp block){
        b.add(block);
    } 
    
     public void removeBullet(BulletUp block){
        b.remove(block);
    } 
}

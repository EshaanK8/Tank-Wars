package main.game.gfx;

import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import Bullets.BulletL;

/**
 *
 * @author Eshaan
 */
public class ControllerLeft {
    private LinkedList<BulletL> b = new LinkedList<BulletL>();
    BulletL TempBulletL;

    Handler handler;
    
    public ControllerLeft(Handler handler){
       this.handler = handler;
       addBullet(new BulletL(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletL = b.get(i);
            TempBulletL.tick();
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletL = b.get(i);
            TempBulletL.render(graphics);
        }
    }
    
    
    public void addBullet(BulletL block){
        b.add(block);
    } 
    
     public void removeBullet(BulletL block){
        b.remove(block);
    } 
}

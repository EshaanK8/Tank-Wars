/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.gfx;

import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import Bullets.BulletD;
import main.game.obstacles.Obstacle;
import static main.game.states.GameState.player1;
import static main.game.states.GameState.player2;
import main.display.Display;
import main.game.states.GameState;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;

/**
 *
 * @author Eshaan
 */
public class ControllerDown {
    private Graphics graphics;
    private LinkedList<BulletD> b = new LinkedList<BulletD>();
    BulletD TempBulletD;
    Handler handler;
    private State menuState;
    public static String win;
    
    
    public ControllerDown(Handler handler){
       this.handler = handler;
       addBullet(new BulletD(500,500, handler));
       menuState = new MenuState(handler); //Initialize menu state
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletD = b.get(i);
            
            
            if (TempBulletD.x >=1000 || TempBulletD.x<=0 || TempBulletD.y >= 600 || TempBulletD.y<=0){
                removeBullet(TempBulletD);
            }
            
            if (TempBulletD.x >= 94 && TempBulletD.x<=193 && TempBulletD.y >= 180 && TempBulletD.y<=190){
                removeBullet(TempBulletD);
            }
            
            if (TempBulletD.x >= 192 && TempBulletD.x<=598 && TempBulletD.y >= 31 && TempBulletD.y<=40 ){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle H2S2");
            }
        
            if (TempBulletD.x >= 91 && TempBulletD.x<=145 && TempBulletD.y >= 535 && TempBulletD.y<= 538 ){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V1B");
            }
            if (TempBulletD.x >= 194 && TempBulletD.x<=244 && TempBulletD.y >= 484 && TempBulletD.y<= 487 ){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V2B");
            }
            
            if (TempBulletD.x >= 276 && TempBulletD.x<=492 && TempBulletD.y >= 382 && TempBulletD.y<= 390 ){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle H3S2");
            }
        
        
        
            //Vertical Obstacles
            if (TempBulletD.x >= 56 && TempBulletD.x<=66 && TempBulletD.y >= 140 && TempBulletD.y<=500){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V1S1");
            }
         
            if (TempBulletD.x >= 100 && TempBulletD.x<=110 && TempBulletD.y >= 140 && TempBulletD.y<=500){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V1S2");
            }
         
            if (TempBulletD.x >= 155 && TempBulletD.x<=165 && TempBulletD.y >= 210 && TempBulletD.y<=447){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V2S1");
            }
         
            if (TempBulletD.x >= 155 && TempBulletD.x<=165 && TempBulletD.y >= -8 && TempBulletD.y<=138){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V2S1");
            }
         
            if (TempBulletD.x >= 200 && TempBulletD.x<=209 && TempBulletD.y >= 57 && TempBulletD.y<=447){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V2S2");
            }
         
            if (TempBulletD.x >= 596 && TempBulletD.x<=599 && TempBulletD.y >= -9 && TempBulletD.y<=57){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle H2S");
            }
          
            if (TempBulletD.x >= 254 && TempBulletD.x<=260 && TempBulletD.y >= 90 && TempBulletD.y<=528){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V3S1");
            }
        
            if (TempBulletD.x >= 304 && TempBulletD.x<=308 && TempBulletD.y >= 90 && TempBulletD.y<=528){
                removeBullet(TempBulletD);
                System.out.println ("Obstacle V3S2");
            }
         
        
        
        
        
        
        //Corners
            if (TempBulletD.x>= 100 && TempBulletD.x <= 110 && TempBulletD.y>= 200 && TempBulletD.y <= 210){
                removeBullet(TempBulletD);
                System.out.println ("Corner 1");
            }
        
            if (TempBulletD.x>= 200  && TempBulletD.x <= 209 && TempBulletD.y>= 50 && TempBulletD.y <= 57){
                removeBullet(TempBulletD);
                System.out.println ("Corner 2");
            }
            
          
           
            
            if (((TempBulletD.y >= player2.y-20) && (TempBulletD.y <= player2.y-10)) && ((TempBulletD.x >= player2.x-2) && (TempBulletD.x <= player2.y+46))){
                removeBullet(TempBulletD);
                win = "player1";
                StateManager.setState(menuState); //Set the current state to GameState object
            }
            //System.out.println ("BulletD = " + TempBulletD.x);
            //System.out.println ("Player2 = " + player2.x);
            
            TempBulletD.tick();
            
        }
        
        
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletD = b.get(i);
            TempBulletD.render(graphics);
        }
    }
    
    
    public void addBullet(BulletD block){
        b.add(block);
    } 
    
     public void removeBullet(BulletD block){
        b.remove(block);
    } 
     
     
     public static String getWin (){
         return win;
     }
}

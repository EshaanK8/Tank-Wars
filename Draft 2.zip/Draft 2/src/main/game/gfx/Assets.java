/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.gfx;

import java.awt.image.BufferedImage;

/**
 *
 * @author Eshaan
 */
public class Assets{

    public static BufferedImage player1, player2, playerupgrd;
    public static BufferedImage tank1down, tank1left, tank1right;
    public static BufferedImage bullet, bulletD, bulletR, bulletL;
    public static BufferedImage player1wins, player2wins;
    
    
    //Method that initializes all of the assets- will only be called once
    public static void init(){
        SpriteSheet sheet1 = new SpriteSheet(ImageLoader.loadImage("/textures/Tanks.png"));
        SpriteSheet sheet2 = new SpriteSheet(ImageLoader.loadImage("/textures/TankRight.png"));
        SpriteSheet sheet3 = new SpriteSheet(ImageLoader.loadImage("/textures/TankDown.png"));
        SpriteSheet sheet4 = new SpriteSheet(ImageLoader.loadImage("/textures/TankLeft.png"));
        SpriteSheet sheet5 = new SpriteSheet(ImageLoader.loadImage("/textures/BulletR.png"));
        SpriteSheet sheet6 = new SpriteSheet(ImageLoader.loadImage("/textures/BulletL.png"));
        SpriteSheet sheet7 = new SpriteSheet(ImageLoader.loadImage("/textures/BulletD.png"));
        SpriteSheet sheet8 = new SpriteSheet(ImageLoader.loadImage("/textures/Player1Wins.png"));
        SpriteSheet sheet9 = new SpriteSheet(ImageLoader.loadImage("/textures/Player2Wins.png"));
        
        player1 = sheet1.cropImage (100, 70 , 235, 319);
        player2 = sheet1.cropImage (90, 519 , 262, 323);
        playerupgrd = sheet1.cropImage(48, 895, 343, 435);
        bullet = sheet1.cropImage(484, 411, 36, 92);
        
        tank1down = sheet3.cropImage(57, 22, 236, 324);
        tank1left = sheet4.cropImage(21,58 , 320, 236);
        tank1right = sheet2.cropImage(26, 43, 319, 236);
        
        
        bulletR = sheet5.cropImage(0, 0, 92, 38);
        bulletL = sheet6.cropImage(0, 0, 92, 38);
        bulletD = sheet7.cropImage(0, 0, 38, 92);
        
        player1wins = sheet8.sheet;
        player2wins = sheet9.sheet;
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game;


import main.game.states.StateManager;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */


public class Launcher {

    
    public Launcher(){

}
    
    
    //Main method
    public static void main (String[] args){
        Game game = new Game("Tile Game", 1000, 600); //Create game object and set to variable "game"
        game.start(); //Calls game method (which calls display and runs tick and render methods)
        
        
    }
}   


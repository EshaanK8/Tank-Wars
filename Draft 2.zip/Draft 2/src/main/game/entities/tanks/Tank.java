package main.game.entities.tanks;

import main.game.Handler;
import main.game.entities.Entity;
//import static main.game.obstacles.Obstacle.obstacle;


public abstract class Tank extends Entity {
	
	public static final int DEFAULT_HEALTH = 10;
	public static final float DEFAULT_SPEED = 3.0f;
	
	protected int health;
	protected float speed;
	protected float xMove, yMove;
        public boolean Xmotion, Ymotion;

	public Tank(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, width, height);
		health = DEFAULT_HEALTH;
		speed = DEFAULT_SPEED;
		xMove = 0;
		yMove = 0;
	}
	
	public void move(){
		moveX();
		moveY();
	}
	
	public void moveX(){
            if (Xmotion == true){
                System.out.print (1);
            }

        }
        
        public void moveY(){

            
        }
                    
            
            
		/*if(xMove > 0){//Moving right
                    
                    System.out.println(x);
			int tx = (int) (x + xMove + bounds.x + bounds.width);
			
			if(!collisionWithObstacle(tx, (int) (y + bounds.y)) &&
					!collisionWithObstacle(tx, (int) (y + bounds.y + bounds.height))){
				x += xMove;
			}
		}else if(xMove < 0){//Moving left
			int tx = (int) (x + xMove + bounds.x);
			
			if(!collisionWithObstacle(tx, (int) (y + bounds.y)) &&
					!collisionWithObstacle(tx, (int) (y + bounds.y + bounds.height))){
				x += xMove;
			}
		}*/
	}
	
	/*public void moveY(){
		if(yMove < 0){//Up
			int ty = (int) (y + yMove + bounds.y);
			
			if(!collisionWithObstacle((int) (x + bounds.x), ty) &&
					!collisionWithObstacle((int) (x + bounds.x + bounds.width), ty)){
				y += yMove;
			}
		}else if(yMove > 0){//Down
			int ty = (int) (y + yMove + bounds.y + bounds.height);
			
			if(!collisionWithObstacle((int) (x + bounds.x), ty) &&
					!collisionWithObstacle((int) (x + bounds.x + bounds.width), ty)){
				y += yMove;
			}
		}
        
	}
	*/

/*
	protected boolean collisionWithObstacle(int x, int y){
		return handler
	}
*/

	
	//GETTERS SETTERS
/*
	public float getxMove() {
		return xMove;
	}

	public void setxMove(float xMove) {
		this.xMove = xMove;
	}

	public float getyMove() {
		return yMove;
	}

	public void setyMove(float yMove) {
		this.yMove = yMove;
	}
*/

/*
	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}
	*/





















































/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
package main.game.entities.tanks;

import main.game.entities.Entity;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
/*
public abstract class Tank extends Entity {
    
    public static final int defaultHealth = 10; //Health constant
    public static final float defaultSpeed = 3.0f; //Speed constant
    public static final int TankWidth = 45;
    
    protected int health;//The tank's health
    protected float speed;//the tank's speed
    protected float xMove, yMove;
    
    //Tank class constructor used for the tank's position
    public Tank(Handler handler, int width, int height) {
        super(handler, width, height);
        
        //super(x, y);//Take the position from the entity constructor
        health = defaultHealth;
        speed = defaultSpeed;
    }

    
    ////Getters and setters for health and speed////
    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }
*/


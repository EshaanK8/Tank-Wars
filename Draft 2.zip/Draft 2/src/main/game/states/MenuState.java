/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import main.game.Handler;
import static main.game.gfx.Assets.player1wins;
import main.game.gfx.ControllerDown;

/**
 *
 * @author Eshaan
 */

public class MenuState extends State {
    private GameState gameState;
    public Rectangle playButton = new Rectangle (100,400, 200, 80);
    public Rectangle helpButton = new Rectangle (400,400, 200, 80);
    public Rectangle quitButton = new Rectangle (700,400, 200, 80);
    
    
    
    public MenuState(Handler handler){
        super(handler);
        

    }
    
    
    @Override
    public void tick() {
        if(handler.getMouseManager().isLeftPressed())
            StateManager.setState(handler.getGame().gameState);
            System.out.println (handler.getGame());
    }

    @Override
    public void render(Graphics graphics) {
        Graphics2D g2d = (Graphics2D) graphics;
        graphics.setColor(Color.blue);
        
      if (ControllerDown.getWin() == "player1"){
        graphics.drawImage(player1wins, 80, 80, null);
      }
      
      Font font = new Font("arial", Font.BOLD, 30);
      graphics.setFont(font);
      graphics.drawString("Play", playButton.x+60, playButton.y+50);
      g2d.draw(playButton);
      graphics.drawString("Help", helpButton.x+60, helpButton.y+50);
      g2d.draw(helpButton);
      graphics.drawString("Quit", quitButton.x+60, quitButton.y+50);
      g2d.draw(quitButton);
      
      graphics.setColor(Color.red);
      graphics.fillRect(handler.getMouseManager().getMouseX(), handler.getMouseManager().getMouseY(), 8, 8);
     
    }
    
}


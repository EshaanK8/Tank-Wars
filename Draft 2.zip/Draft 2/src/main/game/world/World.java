/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.world;

import main.game.obstacles.Obstacle;
import java.awt.Graphics;
import main.game.Handler;


/**
 *
 * @author Eshaan
 */
public class World {
    private Handler handler;
    
    public World(Handler handler){
        this.handler = handler;
    }
    public void tick(){
        
    }
    
    public void render(Graphics graphics){
        //Borders
        Obstacle.obstacles [0].render (graphics, 0, 0, 10, 1000);//Left border
        Obstacle.obstacles [0].render (graphics, 0, 0, 1000, 10);//Top border
        Obstacle.obstacles [0].render (graphics, 0, 590, 1000, 10);//Bottom border
        Obstacle.obstacles [0].render (graphics, 990, 0, 10, 1000);//Right border
        
        //Horizontal Obstacles
        Obstacle.obstacles [0].render (graphics, 100, 200, 100, 10);
        Obstacle.obstacles [0].render (graphics, 200, 50, 400, 10);
        Obstacle.obstacles [0].render (graphics, 300, 400, 200, 10);
        Obstacle.obstacles [0].render (graphics, 400, 300, 250, 10);
        Obstacle.obstacles [0].render (graphics, 400, 135, 250, 10);
        Obstacle.obstacles [0].render (graphics, 900, 250, 100, 10);
        Obstacle.obstacles [0].render (graphics, 900, 350, 100, 10);
        Obstacle.obstacles [0].render (graphics, 850, 100, 150, 10);
        Obstacle.obstacles [0].render (graphics, 650, 500, 200, 10);
        
        //Vertical bars
        Obstacle.obstacles [0].render (graphics, 100, 200, 10, 300);
        Obstacle.obstacles [0].render (graphics, 200, 50, 10, 400);
        Obstacle.obstacles [0].render (graphics, 300, 150, 10, 450);
        Obstacle.obstacles [0].render (graphics, 500, 300, 10, 200);
        Obstacle.obstacles [0].render (graphics, 500, 135, 10, 80);
        Obstacle.obstacles [0].render (graphics, 650, 135, 10, 80);
        Obstacle.obstacles [0].render (graphics, 750, 200, 10, 200);
        Obstacle.obstacles [0].render (graphics, 650,300, 10, 200);
        Obstacle.obstacles [0].render (graphics, 900, 250, 10, 100);
        Obstacle.obstacles [0].render (graphics, 850, 100, 10, 100);
        Obstacle.obstacles [0].render (graphics, 850, 400, 10, 110);
        
       
    }
    
    
    
    public Obstacle getObstacle(int x, int y){
        if (x<0||y<0||x>= 590||y>= 990) 
            return Obstacle.obstacle;
        return null;
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BulletControl;

import Bullets.BulletD2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import main.game.obstacles.Obstacle;

/**
 *
 * @author Eshaan
 */
public class ControllerDown2 {
    private LinkedList<BulletD2> b = new LinkedList<BulletD2>();
    BulletD2 TempBulletD2;
    Handler handler;
    
    public ControllerDown2(Handler handler){
       this.handler = handler;
       addBullet(new BulletD2(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletD2 = b.get(i);
            
            if (TempBulletD2.x >= 94 && TempBulletD2.x<=193 && TempBulletD2.y >= 180 && TempBulletD2.y<=190){
                removeBullet(TempBulletD2);
            }
            
            if (TempBulletD2.x >= 192 && TempBulletD2.x<=598 && TempBulletD2.y >= 31 && TempBulletD2.y<=40 ){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle H2S2");
            }
        
            if (TempBulletD2.x >= 91 && TempBulletD2.x<=145 && TempBulletD2.y >= 535 && TempBulletD2.y<= 538 ){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V1B");
            }
            if (TempBulletD2.x >= 194 && TempBulletD2.x<=244 && TempBulletD2.y >= 484 && TempBulletD2.y<= 487 ){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V2B");
            }
            
            if (TempBulletD2.x >= 276 && TempBulletD2.x<=492 && TempBulletD2.y >= 382 && TempBulletD2.y<= 390 ){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle H3S2");
            }
        
        
        
            //Vertical Obstacles
            if (TempBulletD2.x >= 56 && TempBulletD2.x<=66 && TempBulletD2.y >= 140 && TempBulletD2.y<=500){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V1S1");
            }
         
            if (TempBulletD2.x >= 100 && TempBulletD2.x<=110 && TempBulletD2.y >= 140 && TempBulletD2.y<=500){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V1S2");
            }
         
            if (TempBulletD2.x >= 155 && TempBulletD2.x<=165 && TempBulletD2.y >= 210 && TempBulletD2.y<=447){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V2S1");
            }
         
            if (TempBulletD2.x >= 155 && TempBulletD2.x<=165 && TempBulletD2.y >= -8 && TempBulletD2.y<=138){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V2S1");
            }
         
            if (TempBulletD2.x >= 200 && TempBulletD2.x<=209 && TempBulletD2.y >= 57 && TempBulletD2.y<=447){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V2S2");
            }
         
            if (TempBulletD2.x >= 596 && TempBulletD2.x<=599 && TempBulletD2.y >= -9 && TempBulletD2.y<=57){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle H2S");
            }
          
            if (TempBulletD2.x >= 254 && TempBulletD2.x<=260 && TempBulletD2.y >= 90 && TempBulletD2.y<=528){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V3S1");
            }
        
            if (TempBulletD2.x >= 304 && TempBulletD2.x<=308 && TempBulletD2.y >= 90 && TempBulletD2.y<=528){
                removeBullet(TempBulletD2);
                System.out.println ("Obstacle V3S2");
            }
         
        
        
        
        
        
        //Corners
            if (TempBulletD2.x>= 100 && TempBulletD2.x <= 110 && TempBulletD2.y>= 200 && TempBulletD2.y <= 210){
                removeBullet(TempBulletD2);
                System.out.println ("Corner 1");
            }
        
            if (TempBulletD2.x>= 200  && TempBulletD2.x <= 209 && TempBulletD2.y>= 50 && TempBulletD2.y <= 57){
                removeBullet(TempBulletD2);
                System.out.println ("Corner 2");
            }
            
            TempBulletD2.tick();
            
        }
        
        
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletD2 = b.get(i);
            TempBulletD2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletD2 block){
        b.add(block);
    } 
    
     public void removeBullet(BulletD2 block){
        b.remove(block);
    } 
     
     public void bounceBullet (BulletD2 block){
            TempBulletD2.y -= 5;

            
            //removeBullet(TempBulletD2);
     }
}

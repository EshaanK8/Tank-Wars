package BulletControl;

import Bullets.BulletR2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;


/**
 *
 * @author Eshaan
 */
public class ControllerRight2 {
    private LinkedList<BulletR2> b = new LinkedList<BulletR2>();
    BulletR2 TempBulletR2;

    Handler handler;
    
    public ControllerRight2(Handler handler){
       this.handler = handler;
       addBullet(new BulletR2(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletR2 = b.get(i);
            TempBulletR2.tick();
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletR2 = b.get(i);
            TempBulletR2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletR2 block){
        b.add(block);
    } 
    
     public void removeBullet(BulletR2 block){
        b.remove(block);
    } 
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BulletControl;

import Bullets.BulletUp2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
public class ControllerUp2 {
    private LinkedList<BulletUp2> b = new LinkedList<BulletUp2>();
    BulletUp2 TempBulletUp2;

    Handler handler;
    
    public ControllerUp2(Handler handler){
       this.handler = handler;
       addBullet(new BulletUp2(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp2 = b.get(i);
            TempBulletUp2.tick();
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp2 = b.get(i);
            TempBulletUp2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletUp2 block){
        b.add(block);
    } 
    
     public void removeBullet(BulletUp2 block){
        b.remove(block);
    } 
}

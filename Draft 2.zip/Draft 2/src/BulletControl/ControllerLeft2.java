package BulletControl;

import Bullets.BulletL2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
public class ControllerLeft2 {
    private LinkedList<BulletL2> b = new LinkedList<BulletL2>();
    BulletL2 TempBulletL2;

    Handler handler;
    
    public ControllerLeft2(Handler handler){
       this.handler = handler;
       addBullet(new BulletL2(500,500, handler));
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletL2 = b.get(i);
            TempBulletL2.tick();
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletL2 = b.get(i);
            TempBulletL2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletL2 block){
        b.add(block);
    } 
    
     public void removeBullet(BulletL2 block){
        b.remove(block);
    } 
}

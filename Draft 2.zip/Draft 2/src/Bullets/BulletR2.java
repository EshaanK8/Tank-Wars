package Bullets;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import main.game.Game;
import main.game.Handler;
import main.game.gfx.Assets;
import static main.game.gfx.Assets.bullet;
import main.game.gfx.SpriteSheet;
import main.game.entities.tanks.Player1;
import main.game.states.State;
import main.game.Handler;
import static main.game.gfx.Assets.player1;
import main.game.states.GameState;


public class BulletR2{
    public Player1 player;
    private double x;
    private double y;
    
   BufferedImage image = Assets.bulletR;
   Handler handler;
    
    public BulletR2(double x, double y, Handler handler){
        this.x = x;
        this.y = y;
        player = GameState.player1;
        this.handler = handler;
    }
    

    
    public void tick(){
        //player.tick();
        x+=5;
        //y-=5;//Speed of the bullet
        //System.out.println (x + "," + y);
         
    }
    
    public void render(Graphics graphics){
        graphics.drawImage(image, (int) x, (int) y, 20, 10, null);
    }
    
    public float getX(){
            return (float) this.x;
        }
    
    public float getY(){
            return (float) this.x;
        }
}
package main.game.entities;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.geom.Line2D;
import main.game.Handler;

public abstract class Entity {

	protected Handler handler;
	protected float x, y;
	protected int width, height;
	protected Rectangle bounds;
	
	public Entity(Handler handler, float x, float y, int width, int height){
		this.handler = handler;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		bounds = new Rectangle(0, 0, width, height);
	}
	
	public abstract void tick();
	
	public abstract void render(Graphics g);

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
	
}



















































/*
package main.game.entities;

import java.awt.Graphics;
import java.awt.Rectangle;
import main.game.Handler;

public abstract class Entity {
    
    protected Handler handler;
    protected int width, height;
    protected Rectangle bounds;
    
    /*
    //protected float x, y; //x and y coordinates of the entity
    //protected int height, width;
    */
    //Constructor

/*
    public Entity(Handler handler, int width, int height){
        
        //this.x = x;
        //this.y = y;
        this.handler = handler;
        this.width = width;
        this.height = height;
        
        
        //Bounding box
        bounds = new Rectangle(0, 0, width, height);
    }
    
    //Tick method for entity
    public abstract void tick();
    
    //Render method for entity
    public abstract void render(Graphics graphics);
*/
    
    
    /*
    ////Getters and setters for x, y, height, width////
    
    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }
*/
    
    /*
    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
    
}
*/
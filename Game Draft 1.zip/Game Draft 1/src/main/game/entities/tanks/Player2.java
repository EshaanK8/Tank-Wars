



























































/*
package main.game.entities.tanks;
import java.awt.Color;
import java.awt.Graphics;
import main.game.Handler;
import main.game.gfx.Assets;
import main.game.obstacles.Obstacle;


public class Player2 extends Tank {
    protected float x2, y2 = 10; //x and y coordinates of the entity
    protected int height, width;
    protected float x2Move, y2Move;
    private Handler handler;
    
    
    public Player2(Handler handler, float x2, float y2) {
        
        //Collision box
        bounds.x = 0;
        bounds.y = 0;
        bounds.width = 45;
        bounds.height = 61;
        x2Move = 0;
        y2Move = 0;
        
        
        //super(x1, y1, 50, 68);//Take the position from the entity constructor
        this.handler = handler;
        this.x2 = x2;
        this.y2 = y2;
    }
    
        
    
	public void move2(){
		moveX2();
		moveY2();
	}
	
	public void moveX(){
		if(x2Move > 0){//Moving right
			int tx = (int) (x2 + x2Move + bounds.x + bounds.width);
			
			if(!collisionWithObstacle(tx, (int) (y2 + bounds.y)) &&
					!collisionWithObstacle(tx, (int) (y2 + bounds.y + bounds.height))){
				x2 += x2Move;
			}
		}else if(x2Move < 0){//Moving left
			int tx = (int) (x2 + x2Move + bounds.x);
			
			if(!collisionWithObstacle(tx, (int) (y2 + bounds.y)) &&
					!collisionWithObstacle(tx, (int) (y2 + bounds.y + bounds.height))){
				x2 += x2Move;
			}
		}
	}
	
	public void moveY(){
		if(y2Move < 0){//Up
			int ty = (int) (y2 + y2Move + bounds.y);
			
			if(!collisionWithObstacle((int) (x2 + bounds.x), ty) &&
					!collisionWithObstacle((int) (x2 + bounds.x + bounds.width), ty)){
				y2 += y2Move;
			}
		}else if(y2Move > 0){//Down
			int ty = (int) (y2 + y2Move + bounds.y + bounds.height);
			
			if(!collisionWithObstacle((int) (x2 + bounds.x), ty) &&
					!collisionWithObstacle((int) (x2 + bounds.x + bounds.width), ty)){
				y2 += y2Move;
			}
		}
	}
	
	protected boolean collisionWithObstacle(int x, int y){
		return handler.getWorld().getObstacle(x, y).isSolid();
	}
    

    
    //Tick method for player1
    public void tick() {
        if (handler.getKeyManager().up2)
            y2 -= 3;
        if (handler.getKeyManager().down2)
            y2 += 3;
        if (handler.getKeyManager().right2)
            x2 += 3;
        if (handler.getKeyManager().left2)
           x2 -= 3;
    }

    //Render method for player1
    public void render(Graphics graphics) {
        graphics.drawImage(Assets.player2, (int) x2, (int) y2, 45, 55, null); //1:1.23 resize ratio
        graphics.setColor(Color.red);
        graphics.fillRect(((int)(x2 + bounds.x)), (int)(y2 + bounds.y), bounds.width, bounds.height);
    }
}
*/
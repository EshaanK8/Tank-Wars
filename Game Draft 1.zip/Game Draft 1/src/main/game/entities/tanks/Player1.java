package main.game.entities.tanks;

import java.awt.Color;
import java.awt.Graphics;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.StrictMath.cos;
import main.game.Handler;
import main.game.gfx.Assets;
import static main.game.gfx.Assets.player1;
import main.game.obstacles.Obstacle;
import static main.game.obstacles.Obstacle.obstacles;


public class Player1 extends Tank {
	
	public Player1(Handler handler, float x, float y) {
		super(handler, x, y, 45, 61);
		//this.x = x;
                //this.y = y;
		bounds.x = 16;
		bounds.y = 32;
		bounds.width = 32;
		bounds.height = 32;

	}

	@Override
	public void tick() {
	if (handler.getKeyManager().up1)
            y -= 3;
            Ymotion = true;
        if (handler.getKeyManager().down1)
            y += 3;
            Ymotion = false;
        if (handler.getKeyManager().right1)
            x += 3;
            Xmotion = true;
        if (handler.getKeyManager().left1)
            x -= 3;
            Xmotion = false;
		move();
        
                
                ////Obstacle detection////
                
        //Horizontal Obstacles
        if (x >= 59 && x<=158 && y >= 140 && y<=150){
            y=138;
            System.out.println ("Obstacle H1S1");
        }
        
        if (x >= 110 && x<=158 && y >= 200 && y<= 210 ){
            y=210;
            System.out.println ("Obstacle H1S2");
        }
        
        if (x >= 209 && x<=598 && y >= 50 && y<= 57 ){
            y=57;
            System.out.println ("Obstacle H2S1");
        }
        
        if (x >= 155 && x<=598 && y >= -9 && y<= 0 ){
            y=-9;
            System.out.println ("Obstacle H2S2");
        }
        
        
        //Vertical Obstacles
         if (x >= 56 && x<=66 && y >= 140 && y<=500){
            x=56;
            System.out.println ("Obstacle V1S1");
         }
         
         if (x >= 100 && x<=110 && y >= 140 && y<=500){
            x=110;
            System.out.println ("Obstacle V1S2");
        }
         
         if (x >= 155 && x<=165 && y >= 210 && y<=447){
            x=155;
            System.out.println ("Obstacle V2S1");
        }
         
         if (x >= 200 && x<=209 && y >= 57 && y<=447){
            x=209;
            System.out.println ("Obstacle V2S2");
        }
         
        
        
        
        
        
        //Corners
        if (x>= 100 && x <= 110 && y>= 200 && y <= 210){
            x=110;
            y=210;
            System.out.println ("Corner 1");
        }
        
         if (x>= 200  && x <= 209 && y>= 50 && y <= 57){
            x=209;
            y=57;
            System.out.println ("Corner 2");
        }

        /*
       
        
        
        */
        
       
                
        }
        
	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.player1, (int) (x), (int) (y), width, height, null);
		
		/*g.setColor(Color.red);
		g.fillRect((int) (x + bounds.x),
				(int) (y + bounds.y),
				bounds.width, bounds.height);*/
                System.out.println (x + "," + y);
	}

        
}























































/*
package main.game.entities.tanks;
import java.awt.Color;
import java.awt.Graphics;
import main.game.Handler;
import main.game.gfx.Assets;

public class Player1 extends Tank {
    protected float x1, y1 = 10; //x and y coordinates of the entity
    protected int height, width;
    protected float x1Move, y1Move;
    private Handler handler;
    
    
    public Player1(Handler handler, float x1, float y1) {
        //super(x1, y1, 50, 68);//Take the position from the entity constructor
        
        //Collision box
        bounds.x = 0;
        bounds.y = 0;
        bounds.width = 45;
        bounds.height = 61;
        
        this.handler = handler;
        this.x1 = x1;
        this.y1 = y1;
    }
    
    public void move1(){
        moveX1();
        moveY1();
    }
    
    public void moveX1(){
        x1 += x1Move;
    }
    
    public void moveY1(){
        y1 += y1Move;
    }

    
    //Tick method for player1
    public void tick() {
        if (handler.getKeyManager().up1)
            y1 -= 3;
        if (handler.getKeyManager().down1)
            y1 += 3;
        if (handler.getKeyManager().right1)
            x1 += 3;
        if (handler.getKeyManager().left1)
           x1 -= 3;
    }

    //Render method for player1
    public void render(Graphics graphics) {
        graphics.drawImage(Assets.player1, (int) x1, (int) y1, 45, 61, null); //1:1.36 resize ratio
        graphics.setColor(Color.red);
        graphics.fillRect(((int)(x1 + bounds.x)), (int)(y1 + bounds.y), bounds.width, bounds.height);
    }
}
*/
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.gfx;

import java.awt.image.BufferedImage;

/**
 *
 * @author Eshaan
 */
public class Assets{

    public static BufferedImage player1, player2, playerupgrd, bullet;
    
    //Method that initializes all of the assets- will only be called once
    public static void init(){
        SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/Tanks.png"));
        
        player1 = sheet.cropImage (100, 70 , 235, 319);
        player2 = sheet.cropImage (90, 519 , 262, 323);
        playerupgrd = sheet.cropImage(48, 895, 343, 435);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.obstacles;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Line2D;


/**
 *
 * @author Eshaan
 */
public class Obstacle {
    public static Obstacle[] obstacles = new Obstacle [256];
    public static Obstacle obstacle = new Obstacle(0);
    
    protected final int id;
    //protected final int xpos;
    //protected final int ypos;
    //protected final int rheight;
    //protected final int rwidth;
    
    public Obstacle(int id){
        this.id = id;
        obstacles[id] = this;
        //Obstacle[id] = this;
        //this.xpos = xpos;
        //this.ypos = ypos;
        //this.rwidth = rwidth;
        //this.rheight = rheight;
    }

    public void tick(){
        
    }
    
     public void render(Graphics graphics, int xpos, int ypos, int rwidth, int rheight){
        graphics.setColor(Color.black);
        graphics.fillRect(xpos, ypos, rwidth, rheight);
        graphics.setColor(Color.red);
        //Line2D line = new Line2D();
        //lines[1].setLine(xpos, ypos, xpos, ypos+rheight);
        graphics.drawLine(xpos, ypos, xpos, ypos+rheight);
    }
    
    public int getId(){
        return id;
    }

    public boolean isSolid() {
        return (true);
    }

    
}
        
 
    



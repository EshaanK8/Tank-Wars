/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

import java.awt.Graphics;
import main.game.Game;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
public class MenuState extends State {
    
    public MenuState(Handler handler){
        super(handler);
    }
    @Override
    public void tick() {
       
    }

    @Override
    public void render(Graphics graphics) {
      
    }
    
}

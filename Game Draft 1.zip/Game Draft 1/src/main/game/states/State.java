/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

import java.awt.Graphics;
import main.game.Game;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
public abstract class State {
    
    protected Handler handler;
    
    //Constructor sets object to game object
    public State(Handler handler){
        this.handler = handler;
    }
    public abstract void tick();
    public abstract void render(Graphics graphics);
    
}

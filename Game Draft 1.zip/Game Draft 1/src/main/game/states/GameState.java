/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

import java.awt.Color;
import java.awt.Graphics;
import main.game.Game;
import main.game.Handler;
import main.game.entities.tanks.Player1;
//import main.game.entities.tanks.Player2;
import main.game.gfx.Assets;
import main.game.obstacles.Obstacle;
import main.game.world.World;

/**
 *
 * @author Eshaan
 */
public class GameState extends State {
    private Player1 player1;
    //private Player2 player2;
    private World world;

    public GameState(Handler handler){
        super(handler);
        world = new World(handler);
        handler.setWorld(world);
        player1 = new Player1(handler, 20, 20);
        //player2 = new Player2(handler, 200, 200, 100, 100);

    }
    
    @Override
    public void tick() {
        world.tick();
        player1.tick();
        //player2.tick();
    }

    @Override
    public void render(Graphics graphics) {
        world.render (graphics);
        player1.render(graphics);
        //player2.render(graphics);
        
        //Obstacle.obstacles [0].render (graphics, 0, 0, 10, 1000);//Left border
        /*
        //graphics.fillRect(0, 0, 1000, 10);//Top border
        //graphics.fillRect(0, 590, 1000, 10);//Bottom border
        //graphics.fillRect(990, 0, 10, 1000);//Right border
        /*
        //Horizontal bars
        graphics.fillRect(100, 200, 100, 10);
        graphics.fillRect(200, 50, 400, 10);
        graphics.fillRect(300, 400, 200, 10);
        graphics.fillRect(400, 300, 250, 10);
        graphics.fillRect(400, 135, 250, 10);
        graphics.fillRect(900, 250, 100, 10);
        graphics.fillRect(900, 350, 100, 10);
        graphics.fillRect(850, 100, 150, 10);
        graphics.fillRect(650, 500, 200, 10);
        
        //Vertical bars
        graphics.fillRect(100, 200, 10, 300);
        graphics.fillRect(200, 50, 10, 400);
        graphics.fillRect(300, 150, 10, 450);
        graphics.fillRect(500, 300, 10, 200);
        graphics.fillRect(500, 135, 10, 80);
        graphics.fillRect(650, 135, 10, 80);
        graphics.fillRect(750, 200, 10, 200);
        graphics.fillRect(650, 300, 10, 200);
        graphics.fillRect(900, 250, 10, 100);
        graphics.fillRect(850, 100, 10, 100);
        graphics.fillRect(850, 400, 10, 110);
*/
    }
    
}


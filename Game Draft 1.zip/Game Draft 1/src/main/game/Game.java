/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import main.display.Display;
import main.game.gfx.Assets;
import static main.game.gfx.Assets.player1;
import main.game.gfx.ImageLoader;
import main.game.input.KeyManager;
//import main.game.input.KeyManager2;
import main.game.states.GameState;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;

/**
 *
 * @author Eshaan
 */

public class Game implements Runnable { //Allow game to be run on a thread
    private Display display;
    public int width, height; //dimension attributes
    public String title; //attribute
    private boolean running = false; //Used for while loop to allow game to run
    private Thread thread;
    private BufferStrategy bs;
    private Graphics graphics; //Allows for drawing to the canvas
    public int hPositionx;
    public int hPositiony;
    public int hHeight;
    public int vPositionx;
    public int vPositiony;
    public int vWidth;
    public int xPos;
    public int yPos;
    public int rwidth;
    public int rheight;
    //public int count;
    
    
    //States
    private State gameState;
    private State menuState;
    
    //Input
    private KeyManager keyManager;
    
    //Handler
    private Handler handler;
    
    
    //Constructor
    public Game(String title, int width, int height){
        this.width = width; 
        this.height = height;
        keyManager = new KeyManager();
        //keyManager2 = new KeyManager2();
    }
    
    
    //Initialization method
    private void init(){
        //Call Display class
        display = new Display(title, width, height);
        display.getFrame().addKeyListener(keyManager);//Add a key listener to the JFrame
        //display.getFrame().addKeyListener(keyManager2);//Add a key listener to the JFrame
        Assets.init();
        
        handler = new Handler(this);
        
        gameState = new GameState(handler); //Initialize game state
        menuState = new MenuState(handler); //Initialize menu state
        StateManager.setState(gameState); //Set the current state to GameState object
    }
    
    //Tick method
    private void tick(){
        keyManager.tick();
        
        
        //If the current state exists, then tick
        if (StateManager.getState() != null)
            StateManager.getState().tick();
    }
    
    //Render method
    private void render(){
        bs = display.getCanvas().getBufferStrategy();
        if (bs == null){ //If the canvas does not have a buffer strategy
            display.getCanvas().createBufferStrategy(3); //Use three buffers
            return;
        }
        graphics = bs.getDrawGraphics();
        //Clear Screen
        graphics.clearRect(0, 0, width, height);
        
        /*
        //Start Drawing
        
        graphics.fillRect(0, 0, 10, 1000);//Left border
        graphics.fillRect(0, 0, 1000, 10);//Top border
        graphics.fillRect(0, 590, 1000, 10);//Bottom border
        graphics.fillRect(990, 0, 10, 1000);//Right border
        /*
        //Horizontal bars
        graphics.fillRect(100, 200, 100, 10);
        graphics.fillRect(200, 50, 400, 10);
        graphics.fillRect(300, 400, 200, 10);
        graphics.fillRect(400, 300, 250, 10);
        graphics.fillRect(400, 135, 250, 10);
        graphics.fillRect(900, 250, 100, 10);
        graphics.fillRect(900, 350, 100, 10);
        graphics.fillRect(850, 100, 150, 10);
        graphics.fillRect(650, 500, 200, 10);
        
        //Vertical bars
        graphics.fillRect(100, 200, 10, 300);
        graphics.fillRect(200, 50, 10, 400);
        graphics.fillRect(300, 150, 10, 450);
        graphics.fillRect(500, 300, 10, 200);
        graphics.fillRect(500, 135, 10, 80);
        graphics.fillRect(650, 135, 10, 80);
        graphics.fillRect(750, 200, 10, 200);
        graphics.fillRect(650, 300, 10, 200);
        graphics.fillRect(900, 250, 10, 100);
        graphics.fillRect(850, 100, 10, 100);
        graphics.fillRect(850, 400, 10, 110);
*/


        
        //If the current state exists, then render
        if (StateManager.getState() != null)
            StateManager.getState().render(graphics);
        
        
        
        
       
        //graphics.drawImage(Assets.player1, x, 10, 50, 68, null); //1:1.36 resize ratio 
        //graphics.drawImage(Assets.player2, 100, 100, 50, 62, null); //1:1.23 resize ratio
        
       
        //End Drawing
        
        
        
       
        bs.show(); //Show the buffer
        graphics.dispose(); //Dispose of the graphics object
    }
    
    //Run method
    public void run(){
        init();
        
        //Variables
        int fps = 60; //Sets frames per second to 60 (ticks and renders per second)
        double timePerTick = 1000000000/fps;//Max time that tick and render methods can run for them to run 60 times/second 
        double delta = 0; //Amount of time needed to call tick and render methods again
        long now; //Current time in nanoseconds
        long lastTime = System.nanoTime();//Nanoseconds the computer runs at as the while loop is started
        long timer = 0; //Times until 1 second to determine tick and render methods were called
        long ticks = 0; //Counts times tick and render have run during a second
        
        
        //Loop for the game to continue
        while(running){
            now = System.nanoTime(); //Determine current time
            
            //Determine when tick and render methods must be called again 
            delta += (now-lastTime)/timePerTick; // (Current time - time since code was run)/ max time for tick and render methods
            timer += now-lastTime;//Time since code was run
            lastTime = now; //Update lastTime to current time
            
            //If time>= 1 then the tick and render methods must start
            if (delta >=1){
                tick();
                render();
                ticks++;
                delta--; //The methods have been run, so subtract by 1
            }
            
            //Displays frames per second for debugging purposes
            if (timer >= 1000000000){
                System.out.println (ticks);
                ticks = 0;
                timer = 0;
            }
        }
        
        stop(); //Call stop method in case code has not yet stopped
        
    }
    
    //Method returns key manager1 object so other classes can access it
    public KeyManager getKeyManager(){
        return keyManager;
    }
   
    
    /*
    //Method to store rectangles
    public void paint (Graphics g) {    
        Rectangle r = new Rectangle( xPos, yPos, rwidth, rheight);
        g.fillRect(
           (int)r.getX(),
           (int)r.getY(),
           (int)r.getWidth(),
           (int)r.getHeight()
        );  
       
    }*/
    
  
    
    //Threads
    //Start thread method
    public synchronized void start(){
        if (running == true)
            return; //Do not execute if run is already = true
        running = true; //Run the game
        thread = new Thread(this); //Initialize thread to this game class 
        thread.start(); //Start the thread
    }
    
    //Stop thread method
    public synchronized void stop(){
        if (running == false)
            return;
        running = false;
        try {
            thread.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}

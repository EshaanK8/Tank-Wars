/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BulletControl;

import static BulletControl.ControllerDown.win;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Handler;
import Bullets.BulletUp;
import static main.game.states.GameState.player2;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;

/**
 *
 * @author Eshaan
 */
public class ControllerUp {
    private LinkedList<BulletUp> b = new LinkedList<BulletUp>();
    BulletUp TempBulletUp;
    Handler handler;
    private State menuState;
    
    public ControllerUp(Handler handler){
       this.handler = handler;
       addBullet(new BulletUp(500,500, handler));
       menuState = new MenuState(handler);
    }


    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp = b.get(i);
            TempBulletUp.tick();
        }
        
         //Win Condition
        if (((TempBulletUp.y >= player2.y) && (TempBulletUp.y <= player2.y + player2.getHeight())) && ((TempBulletUp.x >= player2.x) && (TempBulletUp.x <= player2.x + player2.getWidth()))){
            removeBullet(TempBulletUp);
            win = "player1";
            StateManager.setState(menuState); //Set the current state to GameState object
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp = b.get(i);
            TempBulletUp.render(graphics);
        }

    }
    
    
    public void addBullet(BulletUp block){
        b.add(block);
    } 
    
    public void removeBullet(BulletUp block){
       b.remove(block);
    } 
     
    public static String getWin (){
        return win;
    }
}

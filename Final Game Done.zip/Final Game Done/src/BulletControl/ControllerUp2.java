/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BulletControl;

import static BulletControl.ControllerDown.win;
import Bullets.BulletUp2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Handler;
import static main.game.states.GameState.player1;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;

/**
 *
 * @author Eshaan
 */
public class ControllerUp2 {
    private LinkedList<BulletUp2> b = new LinkedList<BulletUp2>();
    BulletUp2 TempBulletUp2;
    Handler handler;
    private State menuState;
    
    public ControllerUp2(Handler handler){
       this.handler = handler;
       addBullet(new BulletUp2(500,500, handler));
       menuState = new MenuState(handler);
    }

    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp2 = b.get(i);
            TempBulletUp2.tick();
        }
        
         //Win Condition
        if (((TempBulletUp2.y >= player1.y) && (TempBulletUp2.y <= player1.y + player1.getHeight())) && ((TempBulletUp2.x >= player1.x) && (TempBulletUp2.x <= player1.x + player1.getWidth()))){
            removeBullet(TempBulletUp2);
            win = "player2";
            StateManager.setState(menuState); //Set the current state to GameState object
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletUp2 = b.get(i);
            TempBulletUp2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletUp2 block){
        b.add(block);
    } 
    
    public void removeBullet(BulletUp2 block){
        b.remove(block);
    } 
     
    public static String getWin (){
        return win;
     }
}

package BulletControl;

import static BulletControl.ControllerDown.win;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Handler;
import Bullets.BulletL;
import static main.game.states.GameState.player2;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;

/**
 *
 * @author Eshaan
 */
public class ControllerLeft {
    private LinkedList<BulletL> b = new LinkedList<BulletL>();
    BulletL TempBulletL;
    Handler handler;
    private State menuState;
    
    public ControllerLeft(Handler handler){
       this.handler = handler;
       addBullet(new BulletL(500,500, handler));
       menuState = new MenuState(handler); //Initialize menu state
    }

    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletL = b.get(i);
            TempBulletL.tick();
        }
        
        //Win condition
        if (((TempBulletL.y >= player2.y) && (TempBulletL.y <= player2.y + player2.getHeight())) && ((TempBulletL.x >= player2.x) && (TempBulletL.x <= player2.x + player2.getWidth()))){
                removeBullet(TempBulletL);
                win = "player1";
                StateManager.setState(menuState); //Set the current state to GameState object
            }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletL = b.get(i);
            TempBulletL.render(graphics);
        }  
    }
    
    
    public void addBullet(BulletL block){
        b.add(block);
    } 
    
     public void removeBullet(BulletL block){
        b.remove(block);
    } 
     
     public static String getWin (){
         return win;
     }
}

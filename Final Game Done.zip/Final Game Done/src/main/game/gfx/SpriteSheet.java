package main.game.gfx;

import java.awt.image.BufferedImage;
/**
 *
 * @author Eshaan
 */
public class SpriteSheet {
    public BufferedImage sheet;
    
    //Constructor
    public SpriteSheet (BufferedImage sheet){
        this.sheet = sheet;
    }
    
    //Method to crop the spritesheet for an individual sprite
    public BufferedImage cropImage(int x, int y, int width, int height){
        return sheet.getSubimage(x, y, width, height); //Return the cropped image
    }
}

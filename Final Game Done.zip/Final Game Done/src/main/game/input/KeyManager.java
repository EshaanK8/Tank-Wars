package main.game.input;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author Eshaan
 */

public class KeyManager implements KeyListener {
    
    //Keys arrays
    private final boolean[] keys1;
    private final boolean[] keys2;
    private final boolean[] keys3;
 
    //Input variables
    public boolean up1, down1, right1, left1, bullet1; //Input for player 1
    public boolean upStay, downStay, rightStay, leftStay; //Input for player 1
    public boolean up2, down2, right2, left2, bullet2; //Input for player 2
    public boolean space; //Input for player 2
    
    public KeyManager(){
        keys1 = new boolean[256]; //Array for whether key is pressed or released for player
        keys2 = new boolean [256];
        keys3 = new boolean [256];
    } 
    
    public void tick(){
        
        //Set variables to keys for player 1
        up1  = keys1[KeyEvent.VK_UP];
        down1  = keys1[KeyEvent.VK_DOWN];
        right1  = keys1[KeyEvent.VK_RIGHT];
        left1  = keys1[KeyEvent.VK_LEFT];
        bullet1 = keys1[KeyEvent.VK_M];
        
        //Keys to allow player to stay in direction
        upStay = keys2[KeyEvent.VK_UP];
        downStay = keys2[KeyEvent.VK_DOWN];
        rightStay = keys2[KeyEvent.VK_RIGHT];
        leftStay = keys2[KeyEvent.VK_LEFT];

        //Set variables to keys for player 2
        up2  = keys1[KeyEvent.VK_W];
        down2  = keys1[KeyEvent.VK_S];
        right2  = keys1[KeyEvent.VK_D];
        left2  = keys1[KeyEvent.VK_A];  
        bullet2 = keys1[KeyEvent.VK_SPACE];
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        keys1[e.getKeyCode()] = true; //Get keycode for key pressed and set to true
        keys2[e.getKeyCode()] = true; //Get keycode for key pressed and set to true
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keys1[e.getKeyCode()] = false; //Get keycode for key pressed and set to false
    }
    
}

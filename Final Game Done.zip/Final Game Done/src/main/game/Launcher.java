package main.game;

/**
 *
 * @author Eshaan
 */

public class Launcher {
  
    public Launcher(){
}
    
    //Main method
    public static void main (String[] args){
        Game game = new Game("Tile Game", 1000, 600); //Create game object and set to variable "game"
        game.start(); //Calls game method (which calls display and runs tick and render methods)   
    }
}   


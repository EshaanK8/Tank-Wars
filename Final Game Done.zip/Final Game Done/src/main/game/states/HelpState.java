package main.game.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */

public class HelpState extends State {
    private GameState gameState;
    public Rectangle playButton = new Rectangle (100,400, 200, 80);
    public Rectangle quitButton = new Rectangle (700,400, 200, 80);
    
    
    
    public HelpState(Handler handler){
        super(handler);
    }
    
    
    @Override
    public void tick() {
        //If play button is pressed, start gamestate
        if(handler.getMouseManager().isLeftPressed() && (handler.getMouseManager().getMouseX() >= playButton.x) && (handler.getMouseManager().getMouseX() <= playButton.x + playButton.width) && (handler.getMouseManager().getMouseY() >= playButton.y) && (handler.getMouseManager().getMouseY() <= playButton.y + playButton.height))
            StateManager.setState(handler.getGame().gameState);
            System.out.println (handler.getGame());
        
        //If quit button is pressed, close the program
        if(handler.getMouseManager().isLeftPressed() && (handler.getMouseManager().getMouseX() >= quitButton.x) && (handler.getMouseManager().getMouseX() <= quitButton.x + playButton.width) && (handler.getMouseManager().getMouseY() >= quitButton.y) && (handler.getMouseManager().getMouseY() <= quitButton.y + quitButton.height))
            System.exit(0);
    }

    @Override
    public void render(Graphics graphics) {
        Graphics2D g2d = (Graphics2D) graphics;
      

      //UI  
      graphics.setColor(Color.cyan);
      graphics.fillRect(0, 0, 1000, 600);
      graphics.setColor(Color.white);
      g2d.fill(playButton);
      g2d.fill(quitButton);
      graphics.setColor(Color.black);
      Font font1 = new Font("arial", Font.BOLD, 30);
      graphics.setFont(font1);
      graphics.drawString("Play", playButton.x+60, playButton.y+50);
      g2d.draw(playButton);
      graphics.drawString("Quit", quitButton.x+60, quitButton.y+50);
      g2d.draw(quitButton);
      
      //Instructions
      graphics.drawString("The objective of this game is to eliminate the opponent before they", 10, 40);
      graphics.drawString("eliminate you. To eliminate your opponent, you must simply hit them", 10, 90);
      graphics.drawString("with a bullet once.", 10, 140);
      graphics.setColor(Color.RED);
      graphics.drawString("Player 1: Use the arrow keys to move and 'M' to fire a bullet.", 10, 250);
      graphics.drawString("Player 2: Use the 'WASD' keys to move and 'SPACE' to fire a bullet.", 10, 320);
      
      //Mouse
      graphics.fillRect(handler.getMouseManager().getMouseX(), handler.getMouseManager().getMouseY(), 8, 8);//Make mouse trackable
     
    }
    
}
package main.game.states;

import BulletControl.ControllerDown2;
import BulletControl.ControllerLeft2;
import BulletControl.ControllerRight2;
import BulletControl.ControllerUp2;
import Bullets.BulletD2;
import Bullets.BulletL2;
import Bullets.BulletR2;
import Bullets.BulletUp2;
import java.awt.Graphics;
import main.game.Handler;
import Bullets.BulletD;
import Bullets.BulletL;
import Bullets.BulletR;
import Bullets.BulletUp;
import main.game.entities.tanks.Player1;
import main.game.entities.tanks.Player2;
import BulletControl.ControllerUp;
import BulletControl.ControllerDown;
import BulletControl.ControllerRight;
import BulletControl.ControllerLeft;
import main.game.world.World;

/**
 *
 * @author Eshaan
 */
public class GameState extends State{
    
    //Objects
    public static Player1 player1;
    public static Player2 player2;
    public ControllerUp cUp;
    public ControllerDown cDown;
    public ControllerLeft cLeft;
    public ControllerRight cRight;
    public ControllerUp2 cUp2;
    public ControllerDown2 cDown2;
    public ControllerLeft2 cLeft2;
    public ControllerRight2 cRight2;
    private final World world;
    BulletUp TempBulletUp;
    BulletD TempBulletD;
    BulletL TempBulletL;
    BulletR TempBulletR;
    BulletUp2 TempBulletUp2;
    BulletD2 TempBulletD2;
    BulletL2 TempBulletL2;
    BulletR2 TempBulletR2;
    
    //Variables
    private boolean firing1;//Stores if player1 is firing or not
    private long firingTimer1;//Timer between successive fires for player 1
    private final long firingDelay1;//Delay between successive fires player 1
    private boolean firing2;//Stores if player2 is firing or not
    private long firingTimer2;//Timer between successive fires for player 2
    private final long firingDelay2;//Delay between successive fires for player 2
    

    public GameState(Handler handler){
        //Initialization
        super(handler);
        world = new World(handler);
        handler.setWorld(world);
        player1 = new Player1(handler, 20, 20);//Initialize player 1 to a position
        player2 = new Player2(handler, 900, 400);//Initialize player 2 to a position
        cUp = new ControllerUp(handler);
        cDown = new ControllerDown(handler);
        cLeft = new ControllerLeft(handler);
        cRight = new ControllerRight(handler);
        cUp2 = new ControllerUp2(handler);
        cDown2 = new ControllerDown2(handler);
        cLeft2 = new ControllerLeft2(handler);
        cRight2 = new ControllerRight2(handler);
        firing1 = false;//Set firing to false
        firingTimer1 = System.nanoTime();
        firingDelay1 = 200;
        firingTimer2 = System.nanoTime();
        firingDelay2 = 200;
    }
    
    @Override
    public void tick() {
        world.tick();
        player1.tick();
        player2.tick();
        cUp.tick();
        cDown.tick();
        cRight.tick();
        cLeft.tick();
        cUp2.tick();
        cDown2.tick();
        cRight2.tick();
        cLeft2.tick();

        
        ////Bullet production- Player 1////
        //If bulet key is pressed for player 1, fire
        if (handler.getKeyManager().bullet1){
            firing1 = true;
           
            //Determines when and what type of bullet will be fired
            if (firing1) {
                long elapsed = (System.nanoTime()-firingTimer1)/1000000;
            
                //Upwards bullets
                if (elapsed>firingDelay1 && player1.getMotionState() == "up"){
                    cUp.addBullet(new BulletUp(player1.getX()+18,player1.getY()-20, handler));
                    firingTimer1 = System.nanoTime();
                }
            
                //Downward bullets
                if (elapsed>firingDelay1 && player1.getMotionState() == "down"){
                    cDown.addBullet(new BulletD(player1.getX()+18,player1.getY()+55, handler));
                    firingTimer1 = System.nanoTime();
                }
            
                //Leftward bullets
                if (elapsed>firingDelay1 && player1.getMotionState() == "left"){
                    cLeft.addBullet(new BulletL(player1.getX()-20,player1.getY()+25, handler));
                    firingTimer1 = System.nanoTime();
                }
            
                //Rightward bullets
                if (elapsed>firingDelay1 && player1.getMotionState() == "right"){
                    cRight.addBullet(new BulletR(player1.getX()+45,player1.getY()+25, handler));
                    firingTimer1 = System.nanoTime();
                }
            }
        }
        
        
        ////Bullet production- Player 1////
        //If bulet key is pressed for player 1, fire
        if (handler.getKeyManager().bullet2){
            firing2 = true;
           
            //Determines when and what type of bullet will be fired
            if (firing2) {
                long elapsed = (System.nanoTime()-firingTimer2)/1000000;
            
                //Upward bullets
                if (elapsed>firingDelay2 && player2.getMotionState() == "up"){
                    cUp2.addBullet(new BulletUp2(player2.getX()+18,player2.getY()-20, handler));
                    firingTimer2 = System.nanoTime();
                }
                
                //Downward bullets
                if (elapsed>firingDelay2 && player2.getMotionState() == "down"){
                    cDown2.addBullet(new BulletD2(player2.getX()+18,player2.getY()+55, handler));
                    firingTimer2 = System.nanoTime();
                }
            
                //Leftward bullets
                if (elapsed>firingDelay2 && player2.getMotionState() == "left"){
                    cLeft2.addBullet(new BulletL2(player2.getX()-20,player2.getY()+25, handler));
                    firingTimer2 = System.nanoTime();
                }
            
                //Rightward bullets
                if (elapsed>firingDelay1 && player2.getMotionState() == "right"){
                    cRight2.addBullet(new BulletR2(player2.getX()+45,player2.getY()+25, handler));
                    firingTimer2 = System.nanoTime();
                }
            }
        }
    }

    @Override
    public void render(Graphics graphics) {
        world.render (graphics);
        player1.render(graphics);
        player2.render(graphics);
        cUp.render(graphics);
        cLeft.render(graphics);
        cDown.render(graphics);
        cRight.render(graphics);
        cUp2.render(graphics);
        cLeft2.render(graphics);
        cDown2.render(graphics);
        cRight2.render(graphics);
    }
}


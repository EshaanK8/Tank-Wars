package main.game.states;

import java.awt.Graphics;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
public abstract class State {

    private static final State currentState = null;

	protected Handler handler;
	
	public State(Handler handler){
		this.handler = handler;
	}
	
	public abstract void tick();
	
	public abstract void render(Graphics g);
}

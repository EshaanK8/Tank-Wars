package main.game.entities.tanks;

import main.game.Handler;
import main.game.entities.Entity;

public abstract class Tank extends Entity {

    public Tank(Handler handler, float x, float y, int width, int height) {
	super(handler, x, y, width, height);
    }
}
                    
            














































/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
package main.game.entities.tanks;

import main.game.entities.Entity;
import main.game.Handler;

/**
 *
 * @author Eshaan
 */
/*
public abstract class Tank extends Entity {
    
    public static final int defaultHealth = 10; //Health constant
    public static final float defaultSpeed = 3.0f; //Speed constant
    public static final int TankWidth = 45;
    
    protected int health;//The tank's health
    protected float speed;//the tank's speed
    protected float xMove, yMove;
    
    //Tank class constructor used for the tank's position
    public Tank(Handler handler, int width, int height) {
        super(handler, width, height);
        
        //super(x, y);//Take the position from the entity constructor
        health = defaultHealth;
        speed = defaultSpeed;
    }

    
    ////Getters and setters for health and speed////
    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }
*/


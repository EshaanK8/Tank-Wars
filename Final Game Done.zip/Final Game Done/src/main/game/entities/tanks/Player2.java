package main.game.entities.tanks;

import java.awt.Graphics;
import main.game.Handler;
import main.game.gfx.Assets;


public class Player2 extends Tank {
  
    String motionState;//Determines the direction of the player for appropriate firing direction
	
	public Player2(Handler handler, float x, float y) {
		super(handler, x, y, 45, 61);
		bounds.x = 16;
		bounds.y = 32;
		bounds.width = 32;
		bounds.height = 32;
	}

	@Override
	public void tick() {
        
	if (handler.getKeyManager().up2  && !handler.getKeyManager().left2  && !handler.getKeyManager().right2  && !handler.getKeyManager().down2)
            y -= 3;
        
        if (handler.getKeyManager().down2  && !handler.getKeyManager().left2  && !handler.getKeyManager().right2  && !handler.getKeyManager().up2)
            y += 3;
            
        if (handler.getKeyManager().right2  && !handler.getKeyManager().down2  && !handler.getKeyManager().left2  && !handler.getKeyManager().up2)
            x += 3;
            
        if (handler.getKeyManager().left2  && !handler.getKeyManager().right2  && !handler.getKeyManager().down2  && !handler.getKeyManager().up2)
            x -= 3;
        
        ////Obstacle detection////

        //Outer borders
        if (x >= 950){
            x=950;
        }
        
        if (x <= 0){
           x=0;
        }
         
        if (y >= 540){
           y=540;
        }
        
        if (y <= 0){
            y=0;
        }
        
        //Horizontal Obstacles
        if (x >= 59 && x<=158 && y >= 140 && y<=150){
            y=138;
            System.out.println ("Obstacle H1S1");
        }
        
        if (x >= 110 && x<=158 && y >= 200 && y<= 210 ){
            y=210;
            System.out.println ("Obstacle H1S2");
        }
        
        if (x >= 209 && x<=598 && y >= 50 && y<= 57 ){
            y=57;
            System.out.println ("Obstacle H2S1");
        }
        
        if (x >= 155 && x<=598 && y >= -9 && y<= 0 ){
            y=-9;
            System.out.println ("Obstacle H2S2");
        }
        
         if (x >= 56 && x<=110 && y >= 495 && y<= 498 ){
            y=498;
            System.out.println ("Obstacle V1B");
        }
         if (x >= 159 && x<=209 && y >= 444 && y<= 447 ){
            y=447;
            System.out.println ("Obstacle V2B");
        }
         
          if (x >= 308 && x<=455 && y >= 404 && y<= 408 ){
            y=408;
            System.out.println ("Obstacle H3S1");
        }
            
          if (x >= 308 && x<=455 && y >= 342 && y<= 345 ){
            y=342;
            System.out.println ("Obstacle H3S2");
        }
          
        if (x >= 358 && x<=657 && y >= 240 && y<= 250 ){
            y=240;
            System.out.println ("Obstacle H4S1");
        }
        
        if (x >= 358 && x<=605 && y >= 300 && y<= 309 ){
            y=309;
            System.out.println ("Obstacle H4S2");
        }
        
        if (x >= 608 && x<=858 && y >= 500 && y<= 507 ){
            y=507;
            System.out.println ("Obstacle H5S2");
        }
        
        if (x >= 656 && x<=806 && y >= 438 && y<= 448 ){
            y=438;
            System.out.println ("Obstacle H4S1");
        }
        
        if (x >= 859 && x<=947 && y >= 192 && y<= 200 ){
            y=192;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 865 && x<=947 && y >= 351 && y<= 357 ){
            y=357;
            System.out.println ("Obstacle H6");
        }
        
        if (x >= 859 && x<=947 && y >= 100 && y<= 108 ){
            y=108;
            System.out.println ("Obstacle H7");
        }
        
         if (x >= 809 && x<=947 && y >= 39 && y<= 47 ){
            y=39;
            System.out.println ("Obstacle H7");
        }
        
        if (x >= 456 && x<=507 && y >= 488 && y<= 498 ){
            y=498;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 706 && x<=757 && y >= 390 && y<= 399 ){
            y=399;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 706 && x<=757 && y >= 141 && y<= 150 ){
            y=141;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 806 && x<=859 && y >= 342 && y<= 350 ){
            y=342;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 606 && x<=658 && y >= 205 && y<= 213 ){
            y=213;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 456 && x<=508 && y >= 203 && y<= 213 ){
            y=213;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 255 && x<=307 && y >= 90 && y<= 96 ){
            y=90;
            System.out.println ("Obstacle H5");
        }
        
        if (x >= 356 && x<=659 && y >= 134 && y<= 144 ){
            y=144;
            System.out.println ("Obstacle H7");
        }
         
        if (x >= 356 && x<=659 && y >= 75 && y<= 85 ){
            y=75;
            System.out.println ("Obstacle H7");
        }
        
        
        //Vertical Obstacles
         if (x >= 56 && x<=66 && y >= 140 && y<=500){
            x=56;
            System.out.println ("Obstacle V1S1");
         }
         
         if (x >= 100 && x<=110 && y >= 140 && y<=500){
            x=110;
            System.out.println ("Obstacle V1S2");
        }
         
         if (x >= 155 && x<=165 && y >= 210 && y<=447){
            x=155;
            System.out.println ("Obstacle V2S1");
        }
         
          if (x >= 155 && x<=165 && y >= -8 && y<=138){
            x=155;
            System.out.println ("Obstacle V2S1");
        }
         
         if (x >= 200 && x<=209 && y >= 57 && y<=447){
            x=209;
            System.out.println ("Obstacle V2S2");
        }
         
          if (x >= 596 && x<=599 && y >= -9 && y<=57){
            x=599;
            System.out.println ("Obstacle H2S");
        }
          
          if (x >= 254 && x<=260 && y >= 90 && y<=528){
            x=254;
            System.out.println ("Obstacle V3S1");
        }
        
           if (x >= 304 && x<=308 && y >= 90 && y<=528){
            x=308;
            System.out.println ("Obstacle V3S2");
        }
           
           if (x >= 455 && x<=465 && y >= 309 && y<=339){
            x=455;
            System.out.println ("Obstacle V3S2");
        }
           
           if (x >= 500 && x<=509 && y >= 309 && y<=498){
            x=509;
            System.out.println ("Obstacle V3S2");
        }
           
           if (x >= 605 && x<=615 && y >= 309 && y<=506){
            x=605;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 650 && x<=659 && y >= 241 && y<=506){
            x=659;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 650 && x<=659 && y >= 241 && y<=506){
            x=659;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 605 && x<=615 && y >= 144 && y<=213){
            x=605;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 500 && x<=509 && y >= 144 && y<=213){
            x=509;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 455 && x<=505 && y >= 144 && y<=213){
            x=455;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 389 && x<=395 && y >= 76 && y<=143){
            x=389;
            System.out.println ("Obstacle V3S2");
        }
           if (x >=650 && x<=659 && y >= 75 && y<=213){
            x=659;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 806 && x<=816 && y >= 40 && y<=198){
            x=806;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 850 && x<=860 && y >= 108 && y<=197){
            x=860;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 850 && x<=860 && y >= 340 && y<=507){
            x=860;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 806 && x<=816 && y >= 342 && y<=438){
            x=806;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 860 && x<=867 && y >= 192 && y<=357){
            x=860;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 758 && x<=761 && y >= 141 && y<=399){
            x=761;
            System.out.println ("Obstacle V3S2");
        }
           if (x >= 707 && x<=717 && y >= 141 && y<=399){
            x=707;
            System.out.println ("Obstacle V3S2");
        }
              if (x >= 356 && x<=366 && y >= 75 && y<=144){
            x=356;
            System.out.println ("Obstacle V3S2");
        }
    }
        
	@Override
	public void render(Graphics g) {
           /// g.drawImage(Assets.player1, (int) (x), (int) (y), width, height, null);
            
        if (handler.getKeyManager().up2){
            motionState = "up";
            g.drawImage(Assets.player2, (int) (x), (int) (y), width, height, null);
        }
        
        else if (handler.getKeyManager().down2){
            motionState = "down";
            g.drawImage(Assets.tank1down, (int) (x), (int) (y), width, height, null);
        }
            
        else if (handler.getKeyManager().right2){
            motionState = "right";
            g.drawImage(Assets.tank1right, (int) (x), (int) (y), width, height, null);
        }
            
        else if (handler.getKeyManager().left2){
            motionState = "left";
            g.drawImage(Assets.tank1left, (int) (x), (int) (y), width, height, null);
        }
        
        
        else if (!handler.getKeyManager().up2 && !handler.getKeyManager().down2 && !handler.getKeyManager().left2 && !handler.getKeyManager().right2 && motionState == "up"){
            g.drawImage(Assets.player2, (int) (x), (int) (y), width, height, null);
            motionState = "up";
        }
        
        
        else if (!handler.getKeyManager().up2 && !handler.getKeyManager().down2 && !handler.getKeyManager().left2 && !handler.getKeyManager().right2 && motionState == "down"){
            g.drawImage(Assets.tank1down, (int) (x), (int) (y), width, height, null);
            motionState = "down";
        }
        
        
        else if (!handler.getKeyManager().up2 && !handler.getKeyManager().down2 && !handler.getKeyManager().left2 && !handler.getKeyManager().right2 && motionState == "right"){
            g.drawImage(Assets.tank1right, (int) (x), (int) (y), width, height, null);
            motionState = "right";
        }
        
        
        else if (!handler.getKeyManager().up2 && !handler.getKeyManager().down2 && !handler.getKeyManager().left2 && !handler.getKeyManager().right2 && motionState == "left"){
            g.drawImage(Assets.tank1left, (int) (x), (int) (y), width, height, null);
            motionState = "left";
        }    
    }
        
    @Override
        public float getX(){
            return this.x;
        }
        
    @Override
        public float getY(){
            return this.y;
        }
        
        public String getMotionState(){
            return motionState;
        }    
    }   



























































/*
package main.game.entities.tanks;
import java.awt.Color;
import java.awt.Graphics;
import main.game.Handler;
import main.game.gfx.Assets;
import main.game.obstacles.Obstacle;


public class Player2 extends Tank {
    protected float x2, y2 = 10; //x and y coordinates of the entity
    protected int height, width;
    protected float x2Move, y2Move;
    private Handler handler;
    
    
    public Player2(Handler handler, float x2, float y2) {
        
        //Collision box
        bounds.x = 0;
        bounds.y = 0;
        bounds.width = 45;
        bounds.height = 61;
        x2Move = 0;
        y2Move = 0;
        
        
        //super(x1, y1, 50, 68);//Take the position from the entity constructor
        this.handler = handler;
        this.x2 = x2;
        this.y2 = y2;
    }
    
        
    
	public void move2(){
		moveX2();
		moveY2();
	}
	
	public void moveX(){
		if(x2Move > 0){//Moving right
			int tx = (int) (x2 + x2Move + bounds.x + bounds.width);
			
			if(!collisionWithObstacle(tx, (int) (y2 + bounds.y)) &&
					!collisionWithObstacle(tx, (int) (y2 + bounds.y + bounds.height))){
				x2 += x2Move;
			}
		}else if(x2Move < 0){//Moving left
			int tx = (int) (x2 + x2Move + bounds.x);
			
			if(!collisionWithObstacle(tx, (int) (y2 + bounds.y)) &&
					!collisionWithObstacle(tx, (int) (y2 + bounds.y + bounds.height))){
				x2 += x2Move;
			}
		}
	}
	
	public void moveY(){
		if(y2Move < 0){//Up
			int ty = (int) (y2 + y2Move + bounds.y);
			
			if(!collisionWithObstacle((int) (x2 + bounds.x), ty) &&
					!collisionWithObstacle((int) (x2 + bounds.x + bounds.width), ty)){
				y2 += y2Move;
			}
		}else if(y2Move > 0){//Down
			int ty = (int) (y2 + y2Move + bounds.y + bounds.height);
			
			if(!collisionWithObstacle((int) (x2 + bounds.x), ty) &&
					!collisionWithObstacle((int) (x2 + bounds.x + bounds.width), ty)){
				y2 += y2Move;
			}
		}
	}
	
	protected boolean collisionWithObstacle(int x, int y){
		return handler.getWorld().getObstacle(x, y).isSolid();
	}
    

    
    //Tick method for player1
    public void tick() {
        if (handler.getKeyManager().up2)
            y2 -= 3;
        if (handler.getKeyManager().down2)
            y2 += 3;
        if (handler.getKeyManager().right2)
            x2 += 3;
        if (handler.getKeyManager().left2)
           x2 -= 3;
    }

    //Render method for player1
    public void render(Graphics graphics) {
        graphics.drawImage(Assets.player2, (int) x2, (int) y2, 45, 55, null); //1:1.23 resize ratio
        graphics.setColor(Color.red);
        graphics.fillRect(((int)(x2 + bounds.x)), (int)(y2 + bounds.y), bounds.width, bounds.height);
    }
}
*/
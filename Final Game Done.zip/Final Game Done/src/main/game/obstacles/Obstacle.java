package main.game.obstacles;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Eshaan
 */
public class Obstacle {
    public static Obstacle[] obstacles = new Obstacle [256];
    public static Obstacle obstacle = new Obstacle(0);
    protected final int id;

    
    public Obstacle(int id){
        this.id = id;
        obstacles[id] = this;
    }

    public void tick(){
    }
    
     public void render(Graphics graphics, int xpos, int ypos, int rwidth, int rheight){
        graphics.setColor(Color.black);
        graphics.fillRect(xpos, ypos, rwidth, rheight);
        graphics.setColor(Color.red);
        graphics.drawLine(xpos, ypos, xpos, ypos+rheight);
    }
    
    public int getId(){
        return id;
    }
    
}
        
 
    



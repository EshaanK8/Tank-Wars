package main.game.obstacles;

/**
 *
 * @author Eshaan
 */

public class Obstacles extends Obstacle {

    public Obstacles(int id, int xpos, int ypos, int rwidth, int rheight) {
        super(id);
    }
}

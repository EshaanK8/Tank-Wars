package Bullets;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import main.game.gfx.Assets;
import main.game.entities.tanks.Player2;
import main.game.Handler;
import main.game.states.GameState;


public class BulletD2{
    public Player2 player;
    public double x;
    public double y;
    
    
   BufferedImage image = Assets.bulletD;
   Handler handler;
    
    public BulletD2(double x, double y, Handler handler){
        this.x = x;
        this.y = y;
        player = GameState.player2;
        this.handler = handler;
    }    
    
    
    public void tick(){
            y+=5;//Bullet motion
    }
    public void render(Graphics graphics){
        graphics.drawImage(image, (int) x, (int) y, 10, 20, null);
    }
    
    public float getX(){
            return (float) this.x;
        }
    
    public float getY(){
            return (float) this.x;
        }
}
package Bullets;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import main.game.gfx.Assets;
import main.game.entities.tanks.Player2;
import main.game.Handler;
import main.game.states.GameState;


public class BulletR2{
    public Player2 player;
    public double x;
    public double y;
    
   BufferedImage image = Assets.bulletR;
   Handler handler;
    
    public BulletR2(double x, double y, Handler handler){
        this.x = x;
        this.y = y;
        player = GameState.player2;
        this.handler = handler;
    }
    

    
    public void tick(){
        x+=5;//Bullet motion   
    }
    
    public void render(Graphics graphics){
        graphics.drawImage(image, (int) x, (int) y, 20, 10, null);
    }
    
    public float getX(){
            return (float) this.x;
        }
    
    public float getY(){
            return (float) this.x;
        }
}
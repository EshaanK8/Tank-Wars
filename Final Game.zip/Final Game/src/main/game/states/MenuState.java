/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import main.game.Handler;
import static main.game.gfx.Assets.player1wins;
import BulletControl.ControllerDown;
import BulletControl.ControllerDown2;
import BulletControl.ControllerLeft;
import BulletControl.ControllerLeft2;
import BulletControl.ControllerRight;
import BulletControl.ControllerRight2;
import BulletControl.ControllerUp;
import BulletControl.ControllerUp2;
import static main.game.gfx.Assets.player2wins;
import static main.game.gfx.Assets.title;

/**
 *
 * @author Eshaan
 */

public class MenuState extends State {
    private GameState gameState;
    private HelpState helpState;
    public Rectangle playButton = new Rectangle (100,400, 200, 80);
    public Rectangle helpButton = new Rectangle (400,400, 200, 80);
    public Rectangle quitButton = new Rectangle (700,400, 200, 80);
    
    
    
    public MenuState(Handler handler){
        super(handler);
    }
    
    
    @Override
    public void tick() {
             
        if(handler.getMouseManager().isLeftPressed() && (handler.getMouseManager().getMouseX() >= playButton.x) && (handler.getMouseManager().getMouseX() <= playButton.x + playButton.width) && (handler.getMouseManager().getMouseY() >= playButton.y) && (handler.getMouseManager().getMouseY() <= playButton.y + playButton.height))
            StateManager.setState(handler.getGame().gameState);
            System.out.println (handler.getGame());
            
        if(handler.getMouseManager().isLeftPressed() && (handler.getMouseManager().getMouseX() >= quitButton.x) && (handler.getMouseManager().getMouseX() <= quitButton.x + quitButton.width) && (handler.getMouseManager().getMouseY() >= quitButton.y) && (handler.getMouseManager().getMouseY() <= quitButton.y + quitButton.height))
            System.exit(0);
        
        if(handler.getMouseManager().isLeftPressed() && (handler.getMouseManager().getMouseX() >= helpButton.x) && (handler.getMouseManager().getMouseX() <= helpButton.x + helpButton.width) && (handler.getMouseManager().getMouseY() >= helpButton.y) && (handler.getMouseManager().getMouseY() <= helpButton.y + helpButton.height))
            StateManager.setState(handler.getGame().helpState);
            System.out.println (handler.getGame());

    
 
    
    }

    @Override
    public void render(Graphics graphics) {
        Graphics2D g2d = (Graphics2D) graphics;
        graphics.setColor(Color.cyan);
        graphics.fillRect(0, 0, 1000, 600);
        graphics.drawImage(title, 90, 80, null);
        
        
      if ("player1".equals(ControllerDown.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerDown.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerDown2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerDown2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerUp.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerUp.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerUp2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);   
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerUp2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerRight.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerRight.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerRight2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerRight2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerLeft.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerLeft.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }
      
      else if ("player1".equals(ControllerLeft2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player2wins, 80, 270, null);
      }
      
      else if ("player2".equals(ControllerLeft2.getWin())){
        graphics.setColor(Color.black);
        Font font = new Font("arial", Font.BOLD, 30);
        graphics.setFont(font);  
        graphics.drawImage(player1wins, 80, 270, null);
      }

        
    
      
      //UI  
      
      graphics.setColor(Color.white);
      g2d.fill(playButton);
      g2d.fill(helpButton);
      g2d.fill(quitButton);
      
      graphics.setColor(Color.black);
      Font font = new Font("arial", Font.BOLD, 30);
      graphics.setFont(font);
      graphics.drawString("Play", playButton.x+60, playButton.y+50);
      g2d.draw(playButton);
      graphics.drawString("Help", helpButton.x+60, helpButton.y+50);
      g2d.draw(helpButton);
      graphics.drawString("Quit", quitButton.x+60, quitButton.y+50);
      g2d.draw(quitButton);
      
      graphics.setColor(Color.red);
      graphics.fillRect(handler.getMouseManager().getMouseX(), handler.getMouseManager().getMouseY(), 8, 8);//Make mouse trackable
     
    }
    
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

/**
 *
 * @author Eshaan      
 */
public class StateManager {
        
    //////// Set and get state to adjust tick and render methods ////////
    private static State currentState = null; //Holds the state of the game to set tick and render
    
    //Method to set current state
    public static void setState (State state){
        currentState = state;  
    }
    
    //Method to get the current state
    public static State getState(){
        return currentState;
    }
   
}

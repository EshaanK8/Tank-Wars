/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.game.states;

import BulletControl.ControllerDown2;
import BulletControl.ControllerLeft2;
import BulletControl.ControllerRight2;
import BulletControl.ControllerUp2;
import Bullets.BulletD2;
import Bullets.BulletL2;
import Bullets.BulletR2;
import Bullets.BulletUp2;
import java.awt.Graphics;
import main.game.Handler;
import Bullets.BulletD;
import Bullets.BulletL;
import Bullets.BulletR;
import Bullets.BulletUp;
import main.game.entities.tanks.Player1;
import main.game.entities.tanks.Player2;
import BulletControl.ControllerUp;
import BulletControl.ControllerDown;
import BulletControl.ControllerRight;
import BulletControl.ControllerLeft;
import main.game.world.World;

/**
 *
 * @author Eshaan
 */
public class GameState extends State{
    public static Player1 player1;
    public static Player2 player2;
    public ControllerUp cUp;
    public ControllerDown cDown;
    public ControllerLeft cLeft;
    public ControllerRight cRight;
    public ControllerUp2 cUp2;
    public ControllerDown2 cDown2;
    public ControllerLeft2 cLeft2;
    public ControllerRight2 cRight2;
    BulletUp TempBulletUp;
    BulletD TempBulletD;
    BulletL TempBulletL;
    BulletR TempBulletR;
    BulletUp2 TempBulletUp2;
    BulletD2 TempBulletD2;
    BulletL2 TempBulletL2;
    BulletR2 TempBulletR2;
    
    private boolean firing1;
    private long firingTimer1;
    private long firingDelay1;
    
    private boolean firing2;
    private long firingTimer2;
    private long firingDelay2;
    
    
    //private Player2 player2;
    private World world;

    public GameState(Handler handler){
        super(handler);
        world = new World(handler);
        handler.setWorld(world);
        player1 = new Player1(handler, 20, 20);
        player2 = new Player2(handler, 900, 400);
        cUp = new ControllerUp(handler);
        cDown = new ControllerDown(handler);
        cLeft = new ControllerLeft(handler);
        cRight = new ControllerRight(handler);
        cUp2 = new ControllerUp2(handler);
        cDown2 = new ControllerDown2(handler);
        cLeft2 = new ControllerLeft2(handler);
        cRight2 = new ControllerRight2(handler);
        firing1 = false;
        firingTimer1 = System.nanoTime();
        firingDelay1 = 200;
        firingTimer2 = System.nanoTime();
        firingDelay2 = 200;
        //player2 = new Player2(handler, 200, 200, 100, 100);
        //bullet1 = new Bullet1(handler, 100,100);

    }
    
    @Override
    public void tick() {
        world.tick();
        player1.tick();
        player2.tick();
        cUp.tick();
        cDown.tick();
        cRight.tick();
        cLeft.tick();
        cUp2.tick();
        cDown2.tick();
        cRight2.tick();
        cLeft2.tick();
        
        
        
        
        if (handler.getKeyManager().bullet1){
            firing1 = true;
           
        
        if (firing1) {
            long elapsed = (System.nanoTime()-firingTimer1)/1000000;
            
            
            if (elapsed>firingDelay1 && player1.getMotionState() == "up"){
                cUp.addBullet(new BulletUp(player1.getX()+18,player1.getY()-20, handler));
                firingTimer1 = System.nanoTime();

            }
            
            if (elapsed>firingDelay1 && player1.getMotionState() == "down"){
                cDown.addBullet(new BulletD(player1.getX()+18,player1.getY()+55, handler));
                firingTimer1 = System.nanoTime();
            }
            
            if (elapsed>firingDelay1 && player1.getMotionState() == "left"){
                cLeft.addBullet(new BulletL(player1.getX()-20,player1.getY()+25, handler));
                firingTimer1 = System.nanoTime();
            }
            
            if (elapsed>firingDelay1 && player1.getMotionState() == "right"){
                cRight.addBullet(new BulletR(player1.getX()+45,player1.getY()+25, handler));
                firingTimer1 = System.nanoTime();
            }
        }
    }
        
        
        
        if (handler.getKeyManager().bullet2){
            firing2 = true;
           
        
        if (firing2) {
            long elapsed = (System.nanoTime()-firingTimer2)/1000000;
            
            
            if (elapsed>firingDelay2 && player2.getMotionState() == "up"){
                cUp2.addBullet(new BulletUp2(player2.getX()+18,player2.getY()-20, handler));
                firingTimer2 = System.nanoTime();

            }
            
            if (elapsed>firingDelay2 && player2.getMotionState() == "down"){
                cDown2.addBullet(new BulletD2(player2.getX()+18,player2.getY()+55, handler));
                firingTimer2 = System.nanoTime();
            }
            
            if (elapsed>firingDelay2 && player2.getMotionState() == "left"){
                cLeft2.addBullet(new BulletL2(player2.getX()-20,player2.getY()+25, handler));
                firingTimer2 = System.nanoTime();
            }
            
            if (elapsed>firingDelay1 && player2.getMotionState() == "right"){
                cRight2.addBullet(new BulletR2(player2.getX()+45,player2.getY()+25, handler));
                firingTimer2 = System.nanoTime();
            }
        }
    }
}

    @Override
    public void render(Graphics graphics) {
        world.render (graphics);
        player1.render(graphics);
        player2.render(graphics);
        cUp.render(graphics);
        cLeft.render(graphics);
        cDown.render(graphics);
        cRight.render(graphics);
        cUp2.render(graphics);
        cLeft2.render(graphics);
        cDown2.render(graphics);
        cRight2.render(graphics);
        //player2.render(graphics);
        //bullet1.render(graphics);
        
        //Obstacle.obstacles [0].render (graphics, 0, 0, 10, 1000);//Left border
        /*
        //graphics.fillRect(0, 0, 1000, 10);//Top border
        //graphics.fillRect(0, 590, 1000, 10);//Bottom border
        //graphics.fillRect(990, 0, 10, 1000);//Right border
        /*
        //Horizontal bars
        graphics.fillRect(100, 200, 100, 10);
        graphics.fillRect(200, 50, 400, 10);
        graphics.fillRect(300, 400, 200, 10);
        graphics.fillRect(400, 300, 250, 10);
        graphics.fillRect(400, 135, 250, 10);
        graphics.fillRect(900, 250, 100, 10);
        graphics.fillRect(900, 350, 100, 10);
        graphics.fillRect(850, 100, 150, 10);
        graphics.fillRect(650, 500, 200, 10);
        
        //Vertical bars
        graphics.fillRect(100, 200, 10, 300);
        graphics.fillRect(200, 50, 10, 400);
        graphics.fillRect(300, 150, 10, 450);
        graphics.fillRect(500, 300, 10, 200);
        graphics.fillRect(500, 135, 10, 80);
        graphics.fillRect(650, 135, 10, 80);
        graphics.fillRect(750, 200, 10, 200);
        graphics.fillRect(650, 300, 10, 200);
        graphics.fillRect(900, 250, 10, 100);
        graphics.fillRect(850, 100, 10, 100);
        graphics.fillRect(850, 400, 10, 110);
*/
    }
}


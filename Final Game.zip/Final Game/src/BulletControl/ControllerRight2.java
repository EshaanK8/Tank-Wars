package BulletControl;

import static BulletControl.ControllerDown.win;
import Bullets.BulletR2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import static main.game.states.GameState.player1;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;


/**
 *
 * @author Eshaan
 */
public class ControllerRight2 {
    private LinkedList<BulletR2> b = new LinkedList<BulletR2>();
    BulletR2 TempBulletR2;
    Handler handler;
    private State menuState;
    
    public ControllerRight2(Handler handler){
       this.handler = handler;
       addBullet(new BulletR2(500,500, handler));
       menuState = new MenuState(handler);
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletR2 = b.get(i);
            TempBulletR2.tick();
        }
        
        
            if (((TempBulletR2.y >= player1.y) && (TempBulletR2.y <= player1.y + player1.getHeight())) && ((TempBulletR2.x >= player1.x) && (TempBulletR2.x <= player1.x + player1.getWidth()))){
                removeBullet(TempBulletR2);
                win = "player2";
                StateManager.setState(menuState); //Set the current state to GameState object
            }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletR2 = b.get(i);
            TempBulletR2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletR2 block){
        b.add(block);
    } 
    
    public void removeBullet(BulletR2 block){
        b.remove(block);
    } 
     
    public static String getWin (){
         return win;
    }
}


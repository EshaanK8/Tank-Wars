package BulletControl;

import static BulletControl.ControllerDown.win;
import Bullets.BulletL2;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import static main.game.states.GameState.player1;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;

/**
 *
 * @author Eshaan
 */
public class ControllerLeft2 {
    private LinkedList<BulletL2> b = new LinkedList<BulletL2>();
    BulletL2 TempBulletL2;
    private State menuState;

    Handler handler;
    
    public ControllerLeft2(Handler handler){
       this.handler = handler;
       addBullet(new BulletL2(500,500, handler));
       menuState = new MenuState(handler); 
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletL2 = b.get(i);
            TempBulletL2.tick();
            
            
            
            
            if (((TempBulletL2.y >= player1.y) && (TempBulletL2.y <= player1.y + player1.getHeight())) && ((TempBulletL2.x >= player1.x) && (TempBulletL2.x <= player1.x + player1.getWidth()))){
                removeBullet(TempBulletL2);
                win = "player2";
                StateManager.setState(menuState); //Set the current state to GameState object
            }
        }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletL2 = b.get(i);
            TempBulletL2.render(graphics);
        }
    }
    
    
    public void addBullet(BulletL2 block){
        b.add(block);
    } 
    
     public void removeBullet(BulletL2 block){
        b.remove(block);
    } 
     
     public static String getWin (){
         return win;
     }
}

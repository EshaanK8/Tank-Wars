package BulletControl;

import static BulletControl.ControllerDown.win;
import java.awt.Graphics;
import java.util.LinkedList;
import main.game.Game;
import main.game.Handler;
import Bullets.BulletR;
import main.game.states.MenuState;
import main.game.states.State;
import main.game.states.StateManager;
import static main.game.states.GameState.player2;

/**
 *
 * @author Eshaan
 */
public class ControllerRight {
    private LinkedList<BulletR> b = new LinkedList<BulletR>();
    BulletR TempBulletR;
    private State menuState;

    Handler handler;
    
    public ControllerRight(Handler handler){
       this.handler = handler;
       addBullet(new BulletR(500,500, handler));
       menuState = new MenuState(handler);
    }

    
    
    public void tick(){
        for (int i = 0; i < b.size(); i++){
            TempBulletR = b.get(i);
            TempBulletR.tick();
        }
        
        
        
        if (((TempBulletR.y >= player2.y) && (TempBulletR.y <= player2.y + player2.getHeight())) && ((TempBulletR.x >= player2.x) && (TempBulletR.x <= player2.x + player2.getWidth()))){
                removeBullet(TempBulletR);
                win = "player1";
                StateManager.setState(menuState); //Set the current state to GameState object
            }
    }
    
    public void render (Graphics graphics){
        for (int i = 0; i < b.size(); i++){
            TempBulletR = b.get(i);
            TempBulletR.render(graphics);
        }
        
        //Win Condition
        if (((TempBulletR.y >= player2.y) && (TempBulletR.y <= player2.y + player2.getHeight())) && ((TempBulletR.x >= player2.x) && (TempBulletR.x <= player2.x + player2.getWidth()))){
                removeBullet(TempBulletR);
                win = "player1";
                StateManager.setState(menuState); //Set the current state to GameState object
            }
    }
    
    
    public void addBullet(BulletR block){
        b.add(block);
    } 
    
     public void removeBullet(BulletR block){
        b.remove(block);
    } 
     
     public static String getWin (){
         return win;
     }
}

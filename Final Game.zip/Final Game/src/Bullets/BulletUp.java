package Bullets;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import main.game.gfx.Assets;
import main.game.entities.tanks.Player1;
import main.game.Handler;
import main.game.states.GameState;


public class BulletUp{
    public Player1 player;
    public double x;
    public double y;
    private int r;
    private double rad;
    
   BufferedImage image = Assets.bullet;
   Handler handler;
    
    public BulletUp(double x, double y, Handler handler){
        this.x = x;
        this.y = y;
        player = GameState.player1;
        this.handler = handler;
    }
    

    
    public void tick(){
       y-=5; 
    }
    
    public void render(Graphics graphics){
        graphics.drawImage(image, (int) x, (int) y, 10, 20, null);
    }
    
    public float getX(){
            return (float) this.x;
        }
    
    public float getY(){
            return (float) this.x;
        }
}